# eagle-libraries

# References

* https://github.com/MacroYau/MacroYau-Eagle-Libraries/blob/master/esp32.lbr
* https://github.com/sparkfun/SparkFun-Eagle-Libraries/blob/master/SparkFun-Connectors.lbr
* https://github.com/snakeye/eagle-lib/blob/master/lm1117.lbr
* https://github.com/wvanvlaenderen/ESP8266-Eagle_Library/blob/master/esp8266modules.lbr
* https://github.com/zumbik/Eagle-Libraries/blob/master/lm35.lbr
